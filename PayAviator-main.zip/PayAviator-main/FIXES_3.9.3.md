# PayAviator 3.9.3 — one-time bill date persists

- Fixed the non-recurring/one-time bill edit path, which previously attempted to redraw the dashboard before writing the bill to storage. If a widget raised an exception, the calendar showed the new due date but the saved bill remained at the old date.
- A one-time bill edit now writes the bill and any moved payment/override records to durable storage before attempting the calendar/list redraw.
- The saved bill remains the same unique ID and is not converted into a recurring bill or duplicated.
- Recurring-bill occurrence edits keep the 3.9.2 behavior.
- No changes to applicationId, data deletion, signing, backend, or banking. Install as an update.

Tested with browser-simulated restart and an injected dashboard redraw error. Device APK testing remains necessary.
