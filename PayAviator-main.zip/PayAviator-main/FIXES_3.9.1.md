# PayAviator 3.9.1 — Calendar recurring bill persistence

- Save an edited recurring occurrence (e.g. Internet on Oct 5 moved to Oct 12) as a stable one-time replacement; retain the recurring series and its previous occurrences.
- Keep the original date hidden after moving it, avoiding duplicates on the new date.
- Save occurrence details, paid amounts, and the source-to-new-date mapping to persistent local storage and the standard IndexedDB bill store.
- Support editing the moved bill again without reverting it after reopening the app.
- When choosing to move this and future dates, preserve earlier occurrences by splitting the recurrence from the selected date.
- Preserve existing saved data and application ID/signing identity. No uninstall is required.
