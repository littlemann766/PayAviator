# PayAviator 3.2.4 — Visual polish

## Fixes
1. **Bills list primary amount** — Partially paid / unpaid bills now show **remaining** as the large amount (total stays in the meta line). Fully paid shows the paid amount.
2. **Merchant logos** — CSP now allows `https:`/`http:` images so Plaid/favicon logos can load. Removed CSS that forced `font-size:0` on logo marks (that caused empty squares). Bank rows always show a logo or letter mark; domain map expanded (GEICO, Chipotle, UDF, etc.).
3. **Cushion dialog copy** — “Current paycheck used” → **“Paycheck this is based on”**, plus Available Now in the preview and “(none set)” when cushion is $0.
4. **Gauge scale help** — Clarified defaults: First $50, Second $100, Third $250, Maximum $500.
5. **Work-day picker** — Shorter labels (`Mon, Sep 28 · 8.0h · $184.00`) so options don’t wrap awkwardly.

## Files
- `index.html`, `VERSION.txt` → 3.2.4
- Android assets synced
