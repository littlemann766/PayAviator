# PayAviator 3.9.2 — bill calendar save recovery

- Save every bill edit to Android app-private storage as a second durable copy alongside localStorage and IndexedDB (not cloud or banking data).
- Restore a newer durable snapshot on app startup, including recurring-date moves, paid amounts, and deleted-occurrence markers.
- Freeze bill snapshots and serialize IndexedDB writes to avoid old writes overwriting newer edits.
- Show an explicit recurring-edit choice (future months by default, only this occurrence, entire schedule), instead of an ambiguous OK/Cancel prompt.
- Verify the Save result and show failure instead of claiming a write was saved.
- Keep `com.payaviator.app`, the existing keystore/signing configuration, app assets, and stored records. Install as an update; do not uninstall.

Note: Android-native private backup is a recovery fallback, not a replacement for exporting a JSON backup before updates.
