# PayAviator 3.2.1 — Critical fixes

## Math / finance
1. **Monthly bill recurrence** — Bills due on the 29th/30th/31st now fall on the **last day of shorter months** (e.g. Jan 31 → Feb 28/29, Apr 30) instead of never appearing.
2. **Salary check estimates** — Support **weekly / biweekly / semi-monthly / monthly**. Results rounded to **cents**.
3. **Money display** — Primary `money()` formatter rounds to the nearest cent before formatting to reduce floating-point display glitches.

## Visual / layout
4. Extra **bottom padding** so Home actions (“Edit Cushion”, “+ Add Spending”) clear the 6-item bottom nav + safe area.
5. Action buttons and dialog footers use **nowrap** so labels like “Close” / “Save Check” are not clipped mid-word.
6. Mode pills and key labels avoid aggressive ellipsis where possible.
7. Gauge scale is visually softened when Safe-to-Spend is ~$0 (empty state).

## Reliability / UX
8. **Bank sync error toasts** are suppressed when the user has **no linked bank accounts** (local-first use should not show Railway/backend errors).
9. User-facing bank unreachable copy no longer mentions internal “Railway deployment”.
10. Fix layer re-applies after late patches / view changes so overrides are not lost.

## Files touched
- `index.html` (core function fixes + appended fix layer CSS/JS)
- `app.js` (monthly `occurs()` clamp)
- `VERSION.txt` → `3.2.1`
- Android assets synced from root sources

## Not a full rewrite
The app is still a large single-file patch stack (~25k lines). This release prioritizes correctness of money/recurrence and the worst layout/toast issues. A modular split remains recommended for long-term maintenance.


# PayAviator 3.2.2 — Credit limit + bills paid

## Credit limit $200 vs $195
- **Cause:** Edit Balance saved the limit into `limit` while the planner and gauge read `creditLimit`. Bank sync also overwrote the user's number with the issuer-reported limit.
- **Fix:** Save writes both `creditLimit` and `limit`, sets `creditLimitManual=true`, and bank sync no longer overwrites a manual limit. Existing rows migrate `limit` → `creditLimit` when needed.

## Bills paid understated in Monthly Snapshot
- **Cause:** The later `monthlyCashPaidFor` only counted explicit `billPaidAmounts` map entries and dropped the fallback for bills marked paid via older overrides / `b.paid` flags.
- **Fix:** Restored a full scan: payment-date amounts first, then paid flags/amounts for occurrences in range so September totals include all bills you marked paid this month.
