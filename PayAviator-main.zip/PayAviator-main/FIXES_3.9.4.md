# PayAviator 3.9.4 — install over existing app (Android update pipeline)

- This release is based on the actual **3.9.3** source, preserving all prior bill/calendar fixes. The ZIP uploaded in the follow-up was older 3.9.1 source.
- Keeps the Android application ID `com.payaviator.app` unchanged and requires the **original** `payaviator` signing keystore.
- Introduces independent increasing Android `versionCode` starting at 400000. The GitHub Actions signed update workflow assigns `400000 + GITHUB_RUN_NUMBER` for each run, starting above the previous 3.9.3 code of 30903. The visible app version is 3.9.4.
- Adds `.github/workflows/payaviator-signed-update.yml`, which builds the signed RELEASE APK and refuses to build if the existing signing secrets are unavailable.
- Keeps installed app data storage, banking settings, Android manifest package/identity and bill calculation logic untouched.
- Does not implement silent auto-updates: open the downloaded release APK and Android should offer Update when the installed certificate matches.

**Important:** A signing-certificate mismatch cannot be repaired by JavaScript, Gradle settings or a higher Android version code. If it occurs, retrieve the signing key used for the installed app rather than uninstalling.
