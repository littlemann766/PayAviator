# PayAviator 3.2.3 — Math precision + paycheck recurrence

## What was fixed

### Money / floating-point
1. **Hours × wage** — Gross paycheck amounts from logged hours are now rounded to the **nearest cent** before use.
2. **Salary check estimates** — Already cent-rounded (weekly / biweekly / semi-monthly / monthly); reconfirmed.
3. **Primary money formatter** — Fix layer 3.2.3 re-asserts `window.money` as always cent-rounded.
4. **Bills paid totals** — `monthlyCashPaidFor` results are forced through cent rounding.
5. **Debt payoff simulation results** — Interest and totals from `ppDebtSimulate` are cent-rounded for display consistency.

### Paycheck recurrence
6. **`paycheckOnDate`** no longer treats every non-weekly frequency as biweekly.
   - Explicit support: `one-time`, `weekly`, `biweekly`, `monthly` (end-of-month clamp), `semimonthly` (1st & 15th, or start-day / start+15 pair).
   - Unknown legacy values still fall back to biweekly.

### Bills (still correct from 3.2.1)
7. Monthly bills due on the 29th/30th/31st clamp to the **last day** of shorter months.

### Credit limit (still correct from 3.2.2)
8. Edit Balance writes both `creditLimit` and `limit`, sets `creditLimitManual`, and bank sync does not overwrite a manual limit.

### Version / packaging
9. Stale hardcoded `3.2.0` display text updated.
10. `VERSION.txt` and `BUNDLED_VERSION` → **3.2.3**.
11. Android assets kept in sync with authoritative root web sources.

## Files touched
- `index.html` (paycheck amount cent-rounding, paycheckOnDate, version, fix layer 3.2.3)
- `VERSION.txt` → `3.2.3`
- `app/src/main/assets/*` synced
- `FIXES_3.2.3.md` (this file)

## Verification
- All active inline scripts parse with no syntax errors.
- Foundation verifier passes (`python3 tools/verify-foundation.py`).
- Unit checks: monthly bill clamp, salary schedules, cents, paycheck frequencies, min-payment formula.
