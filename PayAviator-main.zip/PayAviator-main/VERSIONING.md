# PayAviator versioning and in-place Android updates

Current release: **3.9.4**. A display version advances from `.0` to `.9`, then rolls to the next minor: `3.9.4` → ... → `3.9.9` → `3.10.0`.

**Do not derive Android's versionCode from the display version.** The app has undergone earlier major-version resets, so deriving it from semantic versions risks a downgrade.

- `VERSION.txt`: visible release version (`3.9.4`)
- `ANDROID_VERSION_CODE.txt`: stable Android install/upgrade code floor (`400000`)
- GitHub Actions `.github/workflows/payaviator-signed-update.yml`: sets actual `PAYAVIATOR_ANDROID_VERSION_CODE = floor + GITHUB_RUN_NUMBER` so each new build has a higher Android version code.
- `app/build.gradle`: uses that workflow code while retaining `versionName` from `VERSION.txt`.

Never change the Android app ID `com.payaviator.app`, and always reuse the signing key that signed the installed app. See `UPDATE_WITHOUT_UNINSTALL.md`.
