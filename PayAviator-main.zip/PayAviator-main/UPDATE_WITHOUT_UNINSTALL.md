# Update PayAviator without uninstalling

## Release: 3.9.4

The app installed on your phone is 3.9.3; this project starts from the previous **3.9.3** code and keeps the calendar / bill changes. Its next user-facing version is **3.9.4**.

**Important: Never uninstall PayAviator just to install a new APK.** It can erase local finance data. Back up your data in PayAviator first.

### GitHub build steps (no command line required)

1. Extract `PayAviator-main.zip` and upload its **contents**, including `.github/workflows/payaviator-signed-update.yml`, into the existing GitHub PayAviator app repository. Keep the original repository and GitHub secrets.
2. In your repository, check **Settings → Secrets and variables → Actions**. The pre-existing secrets **PAYAVIATOR_KEYSTORE_HEX** and **PAYAVIATOR_KEYSTORE_PASSWORD** must still contain the **original** signing key and password from the app already installed. Do **not** generate a new keystore.
3. Open **Actions → PayAviator Signed Update APK → Run workflow**. Let the workflow build the **Release** APK. Don't use a Debug APK or an unrelated old workflow.
4. Open the successful workflow run → Artifacts → **PayAviator-3.9.4-SIGNED-UPDATE**. Download and extract the artifact ZIP to get `app-release.apk`.
5. On your phone, open `app-release.apk`. Android should offer to update PayAviator **without uninstalling**. Your existing bills, hours, calendar, banking connections, and app data should remain in place.

### How the update is made compatible

- Same installed Android package ID: `com.payaviator.app`.
- Same signing certificate: the workflow REUSES your original private keystore secret and alias `payaviator`.
- New `versionName` 3.9.4 and Android `versionCode` 400000 plus the workflow run number, which advances with every new run of this workflow. `ANDROID_VERSION_CODE.txt` defines the permanent update-code floor.
- Root `index.html` is the authoritative installed HTML, and it is freshly packaged into the APK.

### If Android says "App not installed", "Conflicting package", or demands uninstall

Stop there; **do not uninstall**. Common cause is that the current APK was signed with a different certificate (for instance, an earlier GitHub-hosted Debug build). **No code change can override that Android security check.** To update without erasing your data, the new APK must be built using the original installed app's signing key/certificate. Recover the original signing keystore or tell us the exact installation error and which Actions workflow produced your installed 3.9.3 APK.

A matching signature and higher version code allow an in-place APK installation; they do **not** make it a self-updating app. Full automatic updates require app-store or managed-distribution infrastructure.
